<?php

namespace App\Models\VLF\Simulador;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Config;
use App\Models\VLF\Simulador\EquipoPartido;


class Partido extends Model
{
    use HasFactory;

    // Configuraciones partido
    private int $bonus_local;
    private int $diferencia_goles;
    private int $cantidad_suplentes = 7;

    private array $equipos = [];

    /**
     * "Gross" game minute.
     *
     * From 1 to 45 + extra time in the first half, and from
     * 46 to 90 + extra time in the second half. Includes the
     * "extra time" added by the referee at the end of each
     * half on account of injuries/delays.
     *
     */
    private int $minuto;

    /*
     * "Net" game minute.
     *
     * From 1 to 45 in the first half, from 46 to 90 in the
     * second half - used for game / player statistics.
     *
     */
    private int $minuto_formal;

    /**
     * These indicators are used for INJ, RED and YELLOW conditionals
     * each is an array, [0] for team 0, [1] for team 1 and contains
     * the number of the player that was injured or got a card on that
     * minute, or -1 if there is no such player
     */

    private array $indicador_tarjetas_amarilla = array(0, 0);
    private array $indicador_tarjetas_roja = array(0, 0);
    private array $indicador_lesiones = array(0, 0);

    private int $numero_jugadores;

    /**
     * Constructor
     */
    public function __construct(int $idEquipo1, int $idEquipo2) {
        $this->setNumeroJugadores(Config::get('vlf.partido.numero_jugadores') + Config::get('vlf.partido.numero_suplentes'));
        $this->inicializarEquipos($idEquipo1, $idEquipo2);
    }

    /**
     *  GETTERS Y SETTERS
     */
    public function getNumeroJugadores(): int
    {
        return $this->numero_jugadores;
    }

    public function setNumeroJugadores(int $numeroJugadores)
    {
        $this->numero_jugadores = $numeroJugadores;
    }

    public function getEquipo(int $idEquipo): EquipoPartido
    {
        //return $this->equipos[$idEquipo];
        return Arr::get($this->equipos, $idEquipo);
    }


    /**
     * 
     * The game running loop
     * 
     * 
     * The timing logic is as follows:
     * 
     * The game is divided to two structurally identical
     * halves. The difference between the halves is their
     * start times.
     * 
     * For each half, an injury time is added. This time
     * goes into the minute counter, but not into the
     * formal_minute counter (that is needed for reports)
     * 
     */
    public function simularPartido()
    {
        $aux_tiempo_juego_mitad = 45;

        // For de cada mitad
        for ($aux_inicio_mitad = 1; $aux_inicio_mitad < 2 * $aux_tiempo_juego_mitad ; $aux_inicio_mitad += $aux_tiempo_juego_mitad) { 
            if ($aux_inicio_mitad == 1) {
                $aux_mitad = 1;
            } else {
                $aux_mitad = 2;
            }
            $aux_ultimo_minuto_mitad = $aux_inicio_mitad + $aux_tiempo_juego_mitad - 1;
            $aux_en_tiempo_extra = false;
            
            // Juego los minutos de esta mitad
            // $aux_ultimo_minuto_mitad será incrementado por $aux_tiempo_aniadido
            // al final de la mitad
            for ($minuto = $minuto_formal = $aux_inicio_mitad; $minuto <= $aux_ultimo_minuto_mitad; $minuto++) {
                $this->limpiar_indicadores_lesion_tarjetas();
                //$this->recalcular_datos_equipo();
                dump("minuto" . $minuto);
            }
        }
    }

    /**
     * Called in the beginning of every minute to clean the indicators
     * of injuries, yellow and red cards (that are used by conditionals).
     */
    public function limpiar_indicadores_lesion_tarjetas(): void
    {
        $indicador_lesiones[0] = $indicador_tarjetas_amarilla[0] = $indicador_tarjetas_roja[0] = 0;
        $indicador_lesiones[1] = $indicador_tarjetas_amarilla[1] = $indicador_tarjetas_roja[1] = 0;
    }

    /**
     *  This function is called by the game running loop in the
     *  beginning of each minute of the game.
     *  It recalculates player contributions, aggression, fatigue,
     *  team total contributions and shotprob.
     */
    public function recalcular_datos_equipo()
    {
        for($indexEquipo = 0; $indexEquipo <= 1; $indexEquipo++) {
            $this->getEquipo($indexEquipo)->total_habilidad_quite = $this->getEquipo($indexEquipo)->total_habilidad_pase = $this->getEquipo($indexEquipo)->total_habilidad_tiro = 0;
            calc_aggression($indexEquipo);

            // Recalculo la fatiga
            $this->getEquipo($indexEquipo)->getTactica()->recalcularFatiga();

            for ($indexJugador = 2; $indexJugador <= $this->getNumeroJugadores(); $indexJugador++) {
                calc_player_contributions($indexEquipo, $indexJugador);
            }

            adjust_contrib_with_side_balance($indexEquipo);
            calc_team_contributions_total($indexEquipo);
        }

        for ($indexEquipo = 0; $indexEquipo <= 1; $indexEquipo++) {
            calc_shotprob($indexEquipo);
        }
    }

    /**
     * Carga los equipos desde la base y desde la táctica, retorna true si se pueden cargar correctamente
     * 
     * @return boolean
     */
    public function inicializarEquipos(int $idEquipo1, int $idEquipo2): bool
    {
        //INICIALIZO EQUIPO 1
        //$equipo1 = new EquipoPartido($idEquipo1, true);
        $this->equipos = Arr::add($this->equipos, 0, new EquipoPartido($idEquipo1, false));
        $this->equipos = Arr::add($this->equipos, 1, new EquipoPartido($idEquipo2, false));
        // PRUEBA OK
        if ($this->getEquipo(0)->getOK() && $this->getEquipo(1)->getOK()) {
            // PRUEBO CALCULO DE FATIGA
            //$this->getEquipo(0)->getTactica()->recalcularFatiga();
            //PRUEBO MUESTRA DE FATIGA
            /*foreach ($this->getEquipo(0)->getTactica()->getJugadores() as $jugador) {
                dump('ffatiga: ' . $jugador->getFatiga());
            }*/
            // PRUEBO CALCULO DE AGRESIVIDAD
            //dump('agresividad ' . $this->getEquipo(0)->getTactica()->calcularAgresividad());
            // PRUEBO ASIGNACION DE POSICIONES Y LADOS
            /*foreach ($this->getEquipo(0)->getTactica()->getJugadores() as $jugador) {
                dump('nombre: ' . $jugador->getJugador()->nombre);
                dump('posicion: ' . $jugador->getPosicion());
                dump('lado: ' . $jugador->getLado());
            }*/
            // PRUEBO POSICION COMODA
            /*foreach ($this->getEquipo(0)->getTactica()->getJugadores() as $jugador) {
                dump('LADO: ' . $jugador->getLado() . ' LADOS: ' . $jugador->getJugador()->habilidad->lado_preferido . ' COMODO: ' . $jugador->getLadoComodo());
            }*/
            // PRUEBO CONTRIBUCION QUITE INDIVIDUAL
            /*foreach ($this->getEquipo(0)->getTactica()->getJugadores() as $jugador) {
                dump('CONTRIBUCION QUITE: ' . $jugador->getContribucionQuite($this->getEquipo(0)->getTactica()->getTactica()));
            }*/
            // PRUEBO CALCULO DE QUITE
            //dump('quite ' . $this->getEquipo(0)->getTactica()->calcularQuite('O'));
            // PRUEBO CALCULO DE PASE
            //dump('pase ' . $this->getEquipo(0)->getTactica()->calcularPase('O'));
            // PRUEBO CALCULO DE TIRO
            //dump('tiro ' . $this->getEquipo(0)->getTactica()->calcularTiro('O'));
            //dump('indes_pateador_penales ' . $this->getEquipo(0)->getTactica()->getIndexPateadorPenales());
            //dump('pateador_penales ' . $this->getEquipo(0)->getTactica()->obtenerPateadorPenales()->getJugador());
            //dump('calculo probabilidad de tiro: ' . $this->getEquipo(0)->getTactica()->calcularProbabilidadTiro('O'));
            //dump("COMPARACION");
            //dump('agresividad 1: ' . $this->getEquipo(0)->getTactica()->calcularAgresividad() . ' | agresividad 2: ' . $this->getEquipo(1)->getTactica()->calcularAgresividad());
            //dump('tactica 1: ' . $this->getEquipo(0)->getTactica()->getTactica() . ' | tactica 2: ' . $this->getEquipo(1)->getTactica()->getTactica());
            //dump('quite 1: ' . $this->getEquipo(0)->getTactica()->calcularQuite($this->getEquipo(1)->getTactica()->getTactica()) . ' | quite 2: ' . $this->getEquipo(1)->getTactica()->calcularQuite($this->getEquipo(0)->getTactica()->getTactica()));
            //dump('pase 1: ' . $this->getEquipo(0)->getTactica()->calcularPase($this->getEquipo(1)->getTactica()->getTactica()) . ' | pase 2: ' . $this->getEquipo(1)->getTactica()->calcularPase($this->getEquipo(0)->getTactica()->getTactica()));
            //dump('tiro 1: ' . $this->getEquipo(0)->getTactica()->calcularTiro($this->getEquipo(1)->getTactica()->getTactica()) . ' | tiro 2: ' . $this->getEquipo(1)->getTactica()->calcularTiro($this->getEquipo(0)->getTactica()->getTactica()));
            //dump('indes_pateador_penales ' . $this->getEquipo(0)->getTactica()->getIndexPateadorPenales());
            //dump('pateador_penales ' . $this->getEquipo(0)->getTactica()->obtenerPateadorPenales()->getJugador());
            //dump('calculo probabilidad de tiro: ' . $this->getEquipo(0)->getTactica()->calcularProbabilidadTiro('O'));
            return true;
        } else {
            dump('error al cargar el equipo');
            return false;
        }
    }
}
