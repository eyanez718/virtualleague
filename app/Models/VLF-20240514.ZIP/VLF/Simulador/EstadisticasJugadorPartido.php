<?php

namespace App\Models\VLF\Simulador;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EstadisticasJugadorPartido extends Model
{
    use HasFactory;

    private int $minutos;
    private int $atajadas;
    private int $quites;
    private int $pases_clave;
    private int $tiros;
    private int $goles;
    private int $faltas;
    private int $asistencias;
    private int $tarjetas_amarillas;
    private int $tarjetas_rojas;

    /**
     * Variables axiliares, usadas para calcular habilidad
     */
    private int $tiros_al_arco;
    private int $tiors_afuera;
    private int $goles_concedidos;

    /**
     * Cambios de habilidad del jugador durante el partido
     */
    private int $progreso_arquero;
    private int $progreso_quite;
    private int $progreso_pase;
    private int $progreso_tiro;
}
