<?php

namespace App\Models\VLF\Simulador;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EstadisticasEquipoPartido extends Model
{
    use HasFactory;

    private int $goles;
    private int $tiros_al_arco;
    private int $tiros_afuera;
    private int $faltas;
    private int $sustituciones;
    private int $lesiones;
}
