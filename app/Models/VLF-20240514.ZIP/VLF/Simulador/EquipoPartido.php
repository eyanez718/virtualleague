<?php

namespace App\Models\VLF\Simulador;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\VLF\Equipo;
use App\Models\VLF\Simulador\EstadisticasEquipoPartido;
use App\Models\VLF\Simulador\TacticaEquipoPartido;

class EquipoPartido extends Model
{
    use HasFactory;

    private Equipo $equipo;
    private EstadisticasEquipoPartido $estadisticas;
    private TacticaEquipoPartido $tactica;
    private bool $ok;

    public function __construct(int $idEquipo, bool $localia) {
        $this->setEquipo(Equipo::with('jugadores')
                                ->find($idEquipo));
        $this->setTactica(new TacticaEquipoPartido($idEquipo, $this->equipo->jugadores, $localia));
        if ($this->getTactica()->getOK()) {
            $this->setOK(true);
        } else {
            $this->setOK(false);
        }
    }

    /**
     * GETTERS Y SETTERS
     */
    public function getEquipo(): Equipo
    {
        return $this->equipo;
    }
    public function setEquipo(Equipo $equipo)
    {
        $this->equipo = $equipo;
    }
    public function getTactica(): TacticaEquipoPartido
    {
        return $this->tactica;
    }
    public function setTactica(TacticaEquipoPartido $tactica)
    {
        $this->tactica = $tactica;
    }
    public function getOK(): bool
    {
        return $this->ok;
    }
    public function setOK($ok)
    {
        $this->ok = $ok;
    }
}
